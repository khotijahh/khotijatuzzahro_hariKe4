package com.example.khotijatuzzahro_harike4

data class DataKalku(
    val Bil1 :String,
    val Bil2 :String,
    val hasil :String
)